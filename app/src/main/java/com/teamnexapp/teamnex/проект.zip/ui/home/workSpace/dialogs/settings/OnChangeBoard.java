package com.teamnexapp.teamnex.ui.home.workSpace.dialogs.settings;

public interface OnChangeBoard {
    void onDelete();
    void onDisconnect();
    void onEdit(String name);
}
