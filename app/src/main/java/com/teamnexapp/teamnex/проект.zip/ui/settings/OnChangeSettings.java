package com.teamnexapp.teamnex.ui.settings;

public interface OnChangeSettings {
    void onChangeLanguage(String language);
}
