package com.teamnexapp.teamnex.ui.home.workSpace.dialogs.card;

public interface OnDeleteCard {
    void onDelete();
}
