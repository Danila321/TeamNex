package com.teamnexapp.teamnex.ui.home;

public interface OnCreateConnectBoard {
    void onChange();
}
